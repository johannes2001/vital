import './App.css';
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import './index.css';
import axios from 'axios';



class NameForm extends React.Component {
  
  state = {
    amount: '',
    token:'',
    numero:'',
    message:'',
    isWaiting: false,
    returnUrl :''
  }

  componentDidMount(){
    var ReverseMd5 = require('reverse-md5');
    var rev = ReverseMd5({
      lettersUpper: false,
      lettersLower: true,
      numbers: true,
      special: false,
      whitespace: true,
      maxLen: 12
  });

    var str = window.location.href;
    var url = new URL(str);
    this.setState({isWaiting: false});
       
    var price = '';
    var token ='';

    if(url.search.includes('token='))
    {
      var data=url.search.split('&');
      if(data.length>0)
      {
        var tab = data[0].split('=');
        price = tab[1];
        price = rev(price);
        price = price['str'];
        tab = data[1].split('=');
        token = tab[1];
       
        this.setState({amount: price});
        this.setState({token: token});
      }
    }

    let returnLink = document.getElementById("returnLink");
    returnLink.style.display="none";

}

  handleChange = event => {
    this.setState({ numero: event.target.value });
  }

  handleSubmit = event => {
    event.preventDefault();
    var msg = document.getElementById("message_request");

    if (!this.state.numero){
      msg.textContent = "Numéro invalide";
      msg.classList.add('alert-warning');
      return
    }

    let pay = document.getElementById("pay");
    var loader = document.getElementById('loader');
    var check = document.getElementById('check');
    

    loader.classList.add('loader');
    //check.classList.add('check');
    
    loader.classList.add('active');
    //check.classList.add('active'); 
    pay.style.display="none";
    msg.textContent = "Transaction en cours";
    msg.classList.add('alert-warning');
    this.setState({isWaiting: true});
   
    axios({
      method: 'post',
      url: 'https://api.dev.writer.prestashop.rintio.com/payment_request',
      data: {
          "amount": this.state.amount,
          "currency": "EUR",
          "externalId": "1234",
          "partyId": this.state.numero,
      }
    }).then(res => {
      this.setState({isWaiting: false});
      this.setState({returnUrl: 'https://lesgrandesaffaires.com/fr/module/paymentexample/validationAPI?status='+status+'&token='+this.state.token});
      var status = res.status;
      console.log(res.status); 
      //loader.classList.remove('loader');
      loader.classList.remove('loader');
      msg.classList.remove('alert-warning');
      msg.classList.add('alert-danger');
      msg.textContent = "Echec du paiement";
      if(status == '202'){
        msg.classList.remove('alert-danger');
        msg.classList.add('alert-success');
        msg.textContent = "Paiement réussi";
      }
    let returnLink = document.getElementById("returnLink");
    returnLink.style.display="block";
    pay.style.display="none";
      //document.location.href='https://lesgrandesaffaires.com/fr/module/paymentexample/validationAPI?status='+status+'&token='+this.state.token;
    })
   
  }

  render() {
    return (
      
      <div class="container-fluid">
    
         <div class="row">
            <div class="col-xs-12 col-md-3 col-lg-4"> </div>
            <div class="col-xs-12 col-md-6 col-lg-4">
              <div id="form">
                <form  onSubmit={this.handleSubmit} class="fixed-center">
                  <div class="card">
                    <div class="card-header">
                      <div id="form-header">
                        <h3 class="title_card">Paiement par Mobile Money</h3>
                        </div>
                        </div>
                        <div class="card-body">
                          <div id="form-main">
                            <p align="center">
                              <img src="http://rintio.com/wp-content/uploads/2019/10/logo-r.png"height="50px" />
                            </p>
                            <div id="form-item">
                              <input type="tel" placeholder="Numéro de téléphone" name="numero" onChange={this.handleChange}/>
                            </div>
                            <div id="form-item">
                              <input type="number" value= {this.state.amount}  id="amount" />
                            </div> <br></br>
                            <div id="form-footer">
                              <p>
                              <button type="submit" id="pay" class="pay" disabled={this.state.isWaiting == true ? true : false  }>Payer</button>
                              <div id="loader">
                              <div id="check">
                                <span id="check-one" class="check-one"></span>
                                <span id="check-two" class="check-two"></span>
                              </div>
                            </div>
                              <button type="button" id="returnLink" class="btn btn-success">
                                <a href={this.state.returnUrl}>Retourner à la boutique</a>
                                </button>
                              </p>
                              <div class="alert" id="message_request" role="alert"></div>
                            </div>
                            </div>
                        </div>
                  </div>
            </form>
        </div>
    </div>
      <div class="col-xs-4 col-md-3 col-lg-4"> </div>
    </div>
    </div>
    

    );
  }
}

ReactDOM.render(<element/>, document.getElementById('root'));

ReactDOM.render(
  <NameForm />,
  document.getElementById('root')
);

export default App;
